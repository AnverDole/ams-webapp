<?php 


header("location:./search.php");